import React, { useState } from 'react';
import axios from 'axios';

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center', 
    height: '100vh', 
    backgroundColor: '#f4f4f4', 
  },
  formContainer: {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '10px',
    boxShadow: '0 6px 12px rgba(0, 0, 0, 0.1)',
    width: '350px', 
  },
  title: {
    textAlign: 'center',
    marginBottom: '20px',
    color: 'black',
    fontSize: '24px',
  },
  inputGroup: {
    marginBottom: '15px',
  },
  label: {
    display: 'block',
    marginBottom: '5px',
    fontSize: '14px',
    color: '#555',
  },
  input: {
    width: '100%',
    padding: '10px',
    borderRadius: '8px',
    border: '1px solid #ddd',
    fontSize: '14px',
    boxSizing: 'border-box',
    transition: 'border-color 0.3s ease', 
  },

};

const FormularioEndereco = () => {
  const [cep, setCep] = useState('');
  const [endereco, setEndereco] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [estado, setEstado] = useState('');

  const buscarEndereco = async (event) => {
    const cepDigitado = event.target.value;

    if (cepDigitado.length === 8) {
      try {
        const response = await axios.get(`https://viacep.com.br/ws/${cepDigitado}/json/`);
        const dados = response.data;

        setEndereco(dados.logradouro);
        setBairro(dados.bairro);
        setCidade(dados.localidade);
        setEstado(dados.uf);
      } catch (error) {
        console.error('Erro ao buscar endereço:', error);
        alert('Ocorreu um erro ao buscar o endereço');
      }
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.formContainer}>
        <h1 style={styles.title}>Formulário de Endereço</h1>
        <form>
          <div style={styles.inputGroup}>
            <label style={styles.label}>CEP:</label>
            <input
              type="text"
              id="cep"
              value={cep}
              onChange={(e) => setCep(e.target.value)}
              onBlur={buscarEndereco}
              maxLength="8"
              placeholder="Digite o CEP"
              style={styles.input}
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Endereço:</label>
            <input
              type="text"
              id="endereco"
              value={endereco}
              onChange={(e) => setEndereco(e.target.value)}
              placeholder="Endereço"
              readOnly
              style={styles.input}
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Bairro:</label>
            <input
              type="text"
              id="bairro"
              value={bairro}
              onChange={(e) => setBairro(e.target.value)}
              placeholder="Bairro"
              readOnly
              style={styles.input}
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Cidade:</label>
            <input
              type="text"
              id="cidade"
              value={cidade}
              onChange={(e) => setCidade(e.target.value)}
              placeholder="Cidade"
              readOnly
              style={styles.input}
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Estado:</label>
            <input
              type="text"
              id="estado"
              value={estado}
              onChange={(e) => setEstado(e.target.value)}
              placeholder="Estado"
              readOnly
              style={styles.input}
            />
          </div>
        </form>
      </div>
    </div>
  );
};

export default FormularioEndereco;
