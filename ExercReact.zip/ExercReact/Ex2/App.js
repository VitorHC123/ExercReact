import React, { useEffect, useState } from 'react';
import axios from 'axios';

// Estilos em formato de objeto JavaScript
const estilos = {
  containerBlog: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '20px',
    backgroundColor: '#f8f8f8',
    fontFamily: 'Arial, sans-serif',
  },
  tituloBlog: {
    textAlign: 'center',
    fontSize: '2.5rem',
    marginBottom: '30px',
    color: '#333',
  },
  carregando: {
    textAlign: 'center',
    fontSize: '1.5rem',
    color: '#333',
  },
  posts: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
    gap: '20px',
    width: '100%',
    maxWidth: '1000px',
  },
  cardPost: {
    backgroundColor: 'white',
    borderRadius: '8px',
    boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
    padding: '20px',
    height: 'auto',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
  },
  imagemPost: {
    width: '100%',
    height: '200px',
    objectFit: 'cover',
    borderRadius: '8px',
    marginBottom: '15px',
  },
  tituloPost: {
    fontSize: '1.5rem',
    color: '#333',
    marginBottom: '10px',
  },
  corpoPost: {
    fontSize: '1rem',
    color: '#555',
    lineHeight: '1.4',
    marginBottom: '15px',
  },
  botaoMais: {
    padding: '10px 15px',
    backgroundColor: '#3498db',
    color: 'white',
    fontSize: '1rem',
    borderRadius: '5px',
    border: 'none',
    cursor: 'pointer',
    textAlign: 'center',
    textDecoration: 'none',
  },
};

const Blog = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/posts')
      .then(resposta => {
        setPosts(resposta.data);
        
      })
      .catch(erro => {
        console.error("Houve um erro ao carregar os posts!", erro);
        
      });
  }, []);


  return (
    <div style={estilos.containerBlog}>
      <h1 style={estilos.tituloBlog}>Blog de Posts</h1>
      <div style={estilos.posts}>
        {posts.map(post => (
          <div key={post.id} style={estilos.cardPost}>
            <img
              src={`https://via.placeholder.com/150?text=Imagem+Post+${post.id}`}
              alt={`Post ${post.id}`}
              style={estilos.imagemPost}
            />
            <h2 style={estilos.tituloPost}>{post.title}</h2>
            <p style={estilos.corpoPost}>{post.body}</p>
            <button style={estilos.botaoMais}>Ler Mais</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Blog;
